//
//  CustomCell.swift
//  zadatakGPS
//
//  Created by Borut on 19/01/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {

    @IBOutlet weak var lblIDBooking: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblLatitude: UILabel!
    @IBOutlet weak var lblLongitude: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }


}
