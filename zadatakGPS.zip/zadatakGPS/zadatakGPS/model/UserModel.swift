//
//  UserModel.swift
//  zadatakGPS
//
//  Created by Borut on 18/01/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import Foundation

class UserModel: NSObject {
    var _bookingID: Int = 0
    var _status = "PickedUp"
    var _time: String!
    var _lat: Double!
    var _long: Double!
    
    var time: String {
        if _time == nil {
            _time = "00:00"
        }

        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .long
        dateFormatter.timeStyle = .medium
        dateFormatter.dateFormat =  "dd.MM.yyyy hh:mm"
        let currentDate = dateFormatter.string(from: Date())
        self._time = currentDate
        return _time
    }
    var lat: Double {
        if _lat == nil {
            _lat = 0
        }
        return _lat
    }
    var long: Double {
        if _long == nil {
            _long = 0
        }
        return _long
    }
    
}
