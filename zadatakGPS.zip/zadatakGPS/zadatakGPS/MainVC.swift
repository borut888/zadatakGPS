//
//  ViewController.swift
//  zadatakGPS
//
//  Created by Borut on 18/01/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit
import CoreLocation

class MainVC: UIViewController, CLLocationManagerDelegate, UITextFieldDelegate {
    
    @IBOutlet weak var txtStartLocation: UITextField!
    @IBOutlet weak var txtEndLocation: UITextField!
    @IBOutlet weak var txtNmbOfPassengers: UITextField!
    @IBOutlet weak var btnStartRide: UIButton!
    @IBOutlet weak var btnPassengerCollected: UIButton!
    @IBOutlet weak var btnStopOver: UIButton!
    @IBOutlet weak var btnContinueRide: UIButton!
    @IBOutlet weak var btnEndRide: UIButton!
    var ourData = [Rides]()
    let locationsOfModel = UserModel()
    let geoCoder = CLGeocoder()
    let locationManager = CLLocationManager()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    
        txtStartLocation.addTarget(self, action: #selector(editingChanged), for: .editingChanged)
        txtEndLocation.addTarget(self, action: #selector(editingChanged), for: .editingChanged)
        txtNmbOfPassengers.addTarget(self, action: #selector(editingChanged), for: .editingChanged)

    
      btnStartRide.isEnabled = false
        
    }
    //updateing users location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[0]
        let locationsLongitude = location.coordinate.longitude
        let locationsLatitude = location.coordinate.latitude
        data_requestMovingGPS(locationsLatitude, locationsLongitude)
    
    }
    
    @IBAction func btnStartRideAction(_ sender: Any) {
        btnStartRide.isEnabled = false
        btnStopOver.isEnabled = false
        btnContinueRide.isEnabled = false
        btnEndRide.isEnabled = false
        geocoderForConvert(txtValue: txtStartLocation.text!)
        
    }
    @IBAction func btnPassengerCollectedAction(_ sender: Any) {
        btnStopOver.isEnabled = true
        btnEndRide.isEnabled = true
    }
    @IBAction func btnStopOverAction(_ sender: Any) {
        btnStartRide.isEnabled = false
        btnStopOver.isEnabled = false
        btnContinueRide.isEnabled = true
        btnPassengerCollected.isEnabled = false
        btnEndRide.isEnabled = false
        locationManager.stopUpdatingLocation()
    }
    @IBAction func btnContinueAction(_ sender: Any) {
        btnEndRide.isEnabled = true
        locationManager.startUpdatingLocation()
    }
    @IBAction func btnEndRide(_ sender: Any) {
        txtStartLocation.text = ""
        txtEndLocation.text = ""
        txtNmbOfPassengers.text = ""
        btnStopOver.isEnabled = true
        btnContinueRide.isEnabled = true
        btnPassengerCollected.isEnabled = true
        btnEndRide.isEnabled = true
        geocoderForConvert(txtValue: txtEndLocation.text!)
    }
   
    //function for disabling button until the data in textField is entered
    @objc func editingChanged(_ textField: UITextField) {
        guard
            let habit = txtStartLocation.text, !habit.isEmpty,
            let goal = txtEndLocation.text, !goal.isEmpty,
            let frequency = txtNmbOfPassengers.text, !frequency.isEmpty
            else {
                btnStartRide.isEnabled = false
                return
        }
        btnStartRide.isEnabled = true
    }
    //alertBox for wrong city name or street
    func alertBoxNoData() {
        let alert = UIAlertController(title: "Sorry", message: "Your location does not exist.", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

    // converting city or street to latitude or longitude
    func geocoderForConvert(txtValue: String)  {
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(txtValue) { (placemarks, error) in
            
            let placemark = placemarks?.first
            let lat = placemark?.location?.coordinate.latitude
            let lon = placemark?.location?.coordinate.longitude
            self.locationsOfModel._lat = lat
            self.locationsOfModel._long = lon
            self.data_request()
            let ride = Rides(context:context)
            ride.bookingID = Int16(self.locationsOfModel.bookingID)
            ride.time = self.locationsOfModel._time
            ride.latitude = self.locationsOfModel._lat
            ride.longitude = self.locationsOfModel._long
            appDelegate.saveContext()
            
        }
    }
    
    // sending JSON data user has entered
    func data_request()
    {
        let url:NSURL = NSURL(string: "https://test.mother.i-ways.hr?json=1")!
        let session = URLSession.shared
        
        let request = NSMutableURLRequest(url: url as URL)
        request.httpMethod = "POST"
        request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
        
        let paramString = "bookingid : \(locationsOfModel.bookingID)&time : \(locationsOfModel.time)& lat : \(locationsOfModel.lat) & lng : \(locationsOfModel.long)"
        request.httpBody = paramString.data(using: String.Encoding.utf8)
        
        let task = session.dataTask(with: request as URLRequest) {
            (
            data, response, error) in
            
            guard let _:NSData = data as NSData?, let _:URLResponse = response, error == nil else {
                print("error")
                return
            }
            
            let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print(dataString!)
            
        }
        
        task.resume()
    }
    
    // sending JSON regulary to server
   @objc func data_requestMovingGPS(_ someLat: Double, _ someLng: Double)
    {
        let url:NSURL = NSURL(string: "http://httpbin.org/post")!
        let session = URLSession.shared
        
        let request = NSMutableURLRequest(url: url as URL)
        request.httpMethod = "POST"
        request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
        
        let paramString = "bookingid : \(locationsOfModel.bookingID)&time : \(locationsOfModel.time)& lat : \(someLat) & lng : \(someLng)"
        request.httpBody = paramString.data(using: String.Encoding.utf8)
        
        let task = session.dataTask(with: request as URLRequest) {
            (
            data, response, error) in
            
            guard let _:NSData = data as NSData?, let _:URLResponse = response, error == nil else {
                print("error")
                return
            }
            
            let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print(dataString!)
            
        }
        
        task.resume()
    }
}



