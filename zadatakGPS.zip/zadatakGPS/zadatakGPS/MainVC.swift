//
//  ViewController.swift
//  zadatakGPS
//
//  Created by Borut on 18/01/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit
import CoreLocation

class MainVC: UIViewController, CLLocationManagerDelegate, UITextFieldDelegate {
    
    @IBOutlet weak var btnPreviousRide: UIButton!
    @IBOutlet weak var txtStartLocation: UITextField!
    @IBOutlet weak var txtEndLocation: UITextField!
    @IBOutlet weak var txtNmbOfPassengers: UITextField!
    @IBOutlet weak var btnStartRide: UIButton!
    @IBOutlet weak var btnPassengerCollected: UIButton!
    @IBOutlet weak var btnStopOver: UIButton!
    @IBOutlet weak var btnContinueRide: UIButton!
    @IBOutlet weak var btnEndRide: UIButton!
    var ourData = [Rides]()
    let locationsOfModel = UserModel()
    let geoCoder = CLGeocoder()
    let locationManager = CLLocationManager()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
    
        txtStartLocation.addTarget(self, action: #selector(editingChanged), for: .editingChanged)
        txtEndLocation.addTarget(self, action: #selector(editingChanged), for: .editingChanged)
        txtNmbOfPassengers.addTarget(self, action: #selector(editingChanged), for: .editingChanged)
        
        btnStartRide.isEnabled = false
        btnPreviousRide.isEnabled = false
    }
    //updating users location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[0]
        let locationsLongitude = location.coordinate.longitude
        let locationsLatitude = location.coordinate.latitude
        data_requestMovingGPS(locationsLatitude, locationsLongitude)
    
    }
    
    @IBAction func btnStartRideAction(_ sender: Any) {
        btnStartRide.isEnabled = false
        btnStopOver.isEnabled = false
        btnContinueRide.isEnabled = false
        btnEndRide.isEnabled = false
        btnPreviousRide.isEnabled = true
        var bookingId = locationsOfModel._bookingID
        bookingId = bookingId + 1
        locationsOfModel._bookingID = bookingId
        locationManager.startUpdatingLocation()
        geocoderForConvert(txtValue: txtStartLocation.text!)
        
    }
    @IBAction func btnPassengerCollectedAction(_ sender: Any) {
        btnStopOver.isEnabled = true
        btnEndRide.isEnabled = true
    }
    @IBAction func btnStopOverAction(_ sender: Any) {
        btnStartRide.isEnabled = false
        btnStopOver.isEnabled = false
        btnContinueRide.isEnabled = true
        btnPassengerCollected.isEnabled = false
        btnEndRide.isEnabled = false
        locationManager.stopUpdatingLocation()
    }
    @IBAction func btnContinueAction(_ sender: Any) {
        btnEndRide.isEnabled = true
        locationManager.startUpdatingLocation()
    }
    @IBAction func btnEndRide(_ sender: Any) {
        txtStartLocation.text = ""
        txtEndLocation.text = ""
        txtNmbOfPassengers.text = ""
        btnStopOver.isEnabled = true
        btnContinueRide.isEnabled = true
        btnPassengerCollected.isEnabled = true
        btnEndRide.isEnabled = true
        locationManager.stopUpdatingLocation()
        geocoderForConvert(txtValue: txtEndLocation.text!)
    }
   
    //function for disabling button until the data in textField is entered
    @objc func editingChanged(_ textField: UITextField) {
        guard
            let habit = txtStartLocation.text, !habit.isEmpty,
            let goal = txtEndLocation.text, !goal.isEmpty,
            let frequency = txtNmbOfPassengers.text, !frequency.isEmpty
            else {
                btnStartRide.isEnabled = false
                btnPreviousRide.isEnabled = false
                return
        }
        btnStartRide.isEnabled = true
    }
    //alertBox for wrong city name or street
    func alertBoxNoData() {
        let alert = UIAlertController(title: "Sorry", message: "Your location does not exist.", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

    // converting city or street to latitude or longitude
    func geocoderForConvert(txtValue: String)  {
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(txtValue) { (placemarks, error) in
        //clouse where you get locations latitude and logitude by name of street or city

//            let placemark = placemarks?.first
//            let lat = placemark?.location?.coordinate.latitude
//            let lon = placemark?.location?.coordinate.longitude
//            self.locationsOfModel._lat = lat
//            self.locationsOfModel._long = lon
        }
    }
    
    
    // sending JSON regulary to server and saving data
    @objc func data_requestMovingGPS(_ someLat: Double, _ someLng: Double)
    {
        let ride = Rides(context:context)
        let url:NSURL = NSURL(string: "http://httpbin.org/post")!
        let session = URLSession.shared
        
        let request = NSMutableURLRequest(url: url as URL)
        request.httpMethod = "POST"
        request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
        
        let paramString = "bookingid : \(locationsOfModel._bookingID)&time : \(locationsOfModel._time)& lat : \(someLat) & lng : \(someLng)"
        ride.bookingID = Int16(locationsOfModel._bookingID)
        ride.time = locationsOfModel.time
        ride.latitude = someLat
        ride.longitude = someLng
        appDelegate.saveContext()
        request.httpBody = paramString.data(using: String.Encoding.utf8)
        
        let task = session.dataTask(with: request as URLRequest) {
            (
            data, response, error) in
            
            guard let _:NSData = data as NSData?, let _:URLResponse = response, error == nil else {
                print("error")
                return
            }
            
            let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print(dataString!)
            
        }
        
        task.resume()
    }
}



