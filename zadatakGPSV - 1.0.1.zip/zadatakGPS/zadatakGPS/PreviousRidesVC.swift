//
//  PreviousRidesVC.swift
//  zadatakGPS
//
//  Created by Borut on 19/01/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit

class PreviousRidesVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var previousRidesTable: UITableView!
    var ourData = [Rides]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        previousRidesTable.delegate = self
        previousRidesTable.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    //we fetch data in tableview function and show the result
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = previousRidesTable.dequeueReusableCell(withIdentifier: "reuseCell") as! CustomCell
        do {
            ourData = try context.fetch(Rides.fetchRequest())

            cell.lblTime.text = ourData[3].time
            cell.lblIDBooking.text = "\(ourData[0].bookingID)"
            cell.lblLatitude.text = "lat:\(ourData[1].latitude)"
            cell.lblLongitude.text = "lng: \(ourData[2].longitude)"
        } catch {
            //hande erro
        }
        
        return cell
    }
    
}
